using UnityEngine;

public class HeartCollectible : MonoBehaviour
{
   [SerializeField]  private float healthValue;

   [Header("Health Sound")]
   [SerializeField] private AudioClip pickupSound;

   private void OnTriggerEnter2D(Collider2D collision)
   {
    if ( collision.tag == "Player")
    {
        SoundManager.instance.PlaySound(pickupSound);
        collision.GetComponent<Health>().AddHealth(healthValue);
        gameObject.SetActive(false);
    }
   }
}

