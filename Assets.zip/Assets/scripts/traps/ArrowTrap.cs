using UnityEngine;

public class ArrowTrap : MonoBehaviour
{
    [SerializeField] private float attackCooldown;
    [SerializeField] private Transform firePoint;
    [SerializeField] private GameObject[] arrows;

    [Header("Arrow Sound")]
    [SerializeField] private AudioClip arrowSound;
    private float cooldownTimer;

    private void Attack()
    {
        int arrowIndex = FindArrow();

        if (arrowIndex != -1)
        {
            SoundManager.instance.PlaySound(arrowSound);
            arrows[arrowIndex].transform.position = firePoint.position;
            arrows[arrowIndex].GetComponent<EnemyProjectile>().ActivateProjectile();
        }
    }

    private int FindArrow()
    {
        for (int i = 0; i < arrows.Length; i++)
        {
            if (!arrows[i].activeInHierarchy)
            {
                return i;
            }
        }
        return -1; // Mengembalikan -1 jika semua arrows aktif
    }

    private void Update()
    {
        cooldownTimer += Time.deltaTime;

        if (cooldownTimer >= attackCooldown)
        {
            Attack();
            cooldownTimer = 0; // Reset cooldown setelah Attack
        }
    }
}
